package com.arif.ledtvbanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.SettingsStore
import com.arif.ledtvbanner.util.Constants

/** Android TV main menu. Launched from the TV launcher (LEANBACK). */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Auto-start last banner if enabled in settings.
        val settings = SettingsStore(this)
        if (settings.autoStartLastBanner) {
            val last = BannerStore(this).getLastUsed()
            if (last != null) {
                startFullScreen(last.toJson().toString())
            }
        }

        findViewById<Button>(R.id.btnNew).setOnClickListener {
            startActivity(Intent(this, BannerEditorActivity::class.java))
        }
        findViewById<Button>(R.id.btnSaved).setOnClickListener {
            startActivity(Intent(this, SavedBannersActivity::class.java))
        }
        findViewById<Button>(R.id.btnQuickStart).setOnClickListener {
            quickStart()
        }
        findViewById<Button>(R.id.btnMusic).setOnClickListener {
            startActivity(Intent(this, MusicSettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnExit).setOnClickListener {
            finishAffinity()
        }

        // Focus first button so the remote has a starting point.
        findViewById<Button>(R.id.btnNew).requestFocus()
    }

    private fun quickStart() {
        val last = BannerStore(this).getLastUsed()
        if (last == null) {
            android.widget.Toast.makeText(
                this, "Henüz kayıtlı banner yok. Önce bir banner oluşturun.",
                android.widget.Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(this, BannerEditorActivity::class.java))
            return
        }
        startFullScreen(last.toJson().toString())
    }

    private fun startFullScreen(json: String) {
        val i = Intent(this, FullScreenBannerActivity::class.java)
        i.putExtra(Constants.EXTRA_BANNER_JSON, json)
        startActivity(i)
    }
}
