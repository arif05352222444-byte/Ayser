package com.arif.ledtvbanner

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.MusicMode

/**
 * Configures the background sound/video for the last used banner.
 * Local MP3 is picked through the system document picker (also reads USB).
 */
class MusicSettingsActivity : AppCompatActivity() {

    private lateinit var store: BannerStore
    private lateinit var config: BannerConfig

    private lateinit var btnMode: Button
    private lateinit var btnPickMp3: Button
    private lateinit var etRadio: EditText
    private lateinit var etYoutube: EditText
    private lateinit var btnDim: Button
    private lateinit var btnLoop: Button
    private lateinit var seekVolume: SeekBar

    private val pickMp3 =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                config.musicUri = uri.toString()
                config.musicMode = MusicMode.LOCAL_MP3
                updateLabels()
                Toast.makeText(this, "MP3 seçildi.", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)
        store = BannerStore(this)
        config = store.getLastUsed() ?: BannerConfig()

        btnMode = findViewById(R.id.btnMode)
        btnPickMp3 = findViewById(R.id.btnPickMp3)
        etRadio = findViewById(R.id.etRadio)
        etYoutube = findViewById(R.id.etYoutube)
        btnDim = findViewById(R.id.btnDim)
        btnLoop = findViewById(R.id.btnLoop)
        seekVolume = findViewById(R.id.seekVolume)

        etRadio.setText(config.radioUrl)
        etYoutube.setText(config.youtubeUrl)
        seekVolume.progress = config.volume

        btnMode.setOnClickListener {
            val values = MusicMode.values()
            val i = values.indexOf(config.musicMode)
            config.musicMode = values[(i + 1) % values.size]
            updateLabels()
        }
        btnPickMp3.setOnClickListener {
            try {
                pickMp3.launch(arrayOf("audio/*"))
            } catch (e: Exception) {
                Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
        btnDim.setOnClickListener {
            config.youtubeDim = when (config.youtubeDim) {
                0 -> 25; 25 -> 50; 50 -> 75; else -> 0
            }
            updateLabels()
        }
        btnLoop.setOnClickListener {
            config.loop = !config.loop
            updateLabels()
        }
        seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { config.volume = p }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnSaveMusic).setOnClickListener { saveAndClose() }

        updateLabels()
        btnMode.requestFocus()
    }

    private fun updateLabels() {
        btnMode.text = "Kaynak:  ${config.musicMode.label}"
        btnDim.text = "YouTube karartma:  %${config.youtubeDim}"
        btnLoop.text = "Döngü:  ${if (config.loop) "Açık" else "Kapalı"}"
    }

    private fun saveAndClose() {
        config.radioUrl = etRadio.text.toString().trim()
        config.youtubeUrl = etYoutube.text.toString().trim()
        store.setLastUsed(config)
        // Also update the saved copy if a banner with this name exists.
        store.save(config)
        Toast.makeText(this, "Müzik/fon ayarı kaydedildi.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
