package com.arif.ledtvbanner.util

object Constants {
    const val EXTRA_BANNER_JSON = "extra_banner_json"
    const val EXTRA_EDIT_INDEX = "extra_edit_index"
    const val EXTRA_QUICK_START = "extra_quick_start"
}
