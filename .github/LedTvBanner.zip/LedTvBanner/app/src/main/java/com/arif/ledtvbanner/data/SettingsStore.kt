package com.arif.ledtvbanner.data

import android.content.Context

/** App-wide general settings (separate from individual banners). */
class SettingsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("led_settings", Context.MODE_PRIVATE)

    var autoStartLastBanner: Boolean
        get() = prefs.getBoolean("auto_start", false)
        set(v) = prefs.edit().putBoolean("auto_start", v).apply()

    var keepScreenOn: Boolean
        get() = prefs.getBoolean("keep_on", true)
        set(v) = prefs.edit().putBoolean("keep_on", v).apply()

    var startOnBoot: Boolean
        get() = prefs.getBoolean("start_on_boot", false)
        set(v) = prefs.edit().putBoolean("start_on_boot", v).apply()

    var defaultColor: String
        get() = prefs.getString("def_color", TextColor.RED.name) ?: TextColor.RED.name
        set(v) = prefs.edit().putString("def_color", v).apply()

    var defaultSpeed: String
        get() = prefs.getString("def_speed", ScrollSpeed.NORMAL.name) ?: ScrollSpeed.NORMAL.name
        set(v) = prefs.edit().putString("def_speed", v).apply()

    var defaultVolume: Int
        get() = prefs.getInt("def_volume", 80)
        set(v) = prefs.edit().putInt("def_volume", v).apply()

    var defaultYoutubeDim: Int
        get() = prefs.getInt("def_yt_dim", 50)
        set(v) = prefs.edit().putInt("def_yt_dim", v).apply()
}
