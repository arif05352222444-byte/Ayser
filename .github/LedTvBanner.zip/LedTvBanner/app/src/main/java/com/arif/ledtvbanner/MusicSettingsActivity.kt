package com.arif.ledtvbanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.MusicMode
import com.arif.ledtvbanner.data.YoutubeStore
import com.arif.ledtvbanner.util.Constants

/**
 * Configures the background sound/video for the last used banner.
 * Local MP3 is picked through the system document picker (also reads USB).
 * YouTube can be chosen via in-app search (preferred) or a manual link (backup).
 */
class MusicSettingsActivity : AppCompatActivity() {

    private lateinit var store: BannerStore
    private lateinit var ytStore: YoutubeStore
    private lateinit var config: BannerConfig

    private lateinit var btnMode: Button
    private lateinit var btnPickMp3: Button
    private lateinit var etRadio: EditText
    private lateinit var etYoutube: EditText
    private lateinit var btnDim: Button
    private lateinit var btnLoop: Button
    private lateinit var seekVolume: SeekBar
    private lateinit var tvSelectedVideo: TextView

    private val pickMp3 =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                config.musicUri = uri.toString()
                config.musicMode = MusicMode.LOCAL_MP3
                updateLabels()
                Toast.makeText(this, "MP3 seçildi.", Toast.LENGTH_SHORT).show()
            }
        }

    private val youtubeSearch =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val id = result.data?.getStringExtra(Constants.EXTRA_YT_VIDEO_ID)
                val title = result.data?.getStringExtra(Constants.EXTRA_YT_VIDEO_TITLE) ?: ""
                if (!id.isNullOrBlank()) {
                    config.youtubeUrl = "https://www.youtube.com/watch?v=$id"
                    config.musicMode = MusicMode.YOUTUBE
                    etYoutube.setText(config.youtubeUrl)
                    config.selectedVideoTitle = title
                    updateSelectedLabel()
                    updateLabels()
                    Toast.makeText(this, "Video seçildi: $title", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)
        store = BannerStore(this)
        ytStore = YoutubeStore(this)
        config = store.getLastUsed() ?: BannerConfig()

        btnMode = findViewById(R.id.btnMode)
        btnPickMp3 = findViewById(R.id.btnPickMp3)
        etRadio = findViewById(R.id.etRadio)
        etYoutube = findViewById(R.id.etYoutube)
        btnDim = findViewById(R.id.btnDim)
        btnLoop = findViewById(R.id.btnLoop)
        seekVolume = findViewById(R.id.seekVolume)
        tvSelectedVideo = findViewById(R.id.tvSelectedVideo)

        etRadio.setText(config.radioUrl)
        etYoutube.setText(config.youtubeUrl)
        seekVolume.progress = config.volume

        btnMode.setOnClickListener {
            val values = MusicMode.values()
            val i = values.indexOf(config.musicMode)
            config.musicMode = values[(i + 1) % values.size]
            updateLabels()
        }
        btnPickMp3.setOnClickListener {
            try {
                pickMp3.launch(arrayOf("audio/*"))
            } catch (e: Exception) {
                Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnYoutubeSearch).setOnClickListener {
            youtubeSearch.launch(Intent(this, YoutubeSearchActivity::class.java))
        }
        findViewById<Button>(R.id.btnTestYoutube).setOnClickListener { testYoutube() }
        btnDim.setOnClickListener {
            config.youtubeDim = when (config.youtubeDim) {
                0 -> 25; 25 -> 50; 50 -> 75; else -> 0
            }
            updateLabels()
        }
        btnLoop.setOnClickListener {
            config.loop = !config.loop
            updateLabels()
        }
        seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { config.volume = p }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnSaveMusic).setOnClickListener { saveAndClose() }

        updateLabels()
        updateSelectedLabel()
        btnMode.requestFocus()
    }

    private fun updateLabels() {
        btnMode.text = "Kaynak:  ${config.musicMode.label}"
        btnDim.text = "YouTube karartma:  %${config.youtubeDim}"
        btnLoop.text = "Döngü:  ${if (config.loop) "Açık" else "Kapalı"}"
    }

    private fun updateSelectedLabel() {
        val t = config.selectedVideoTitle
        tvSelectedVideo.text = if (t.isNotBlank()) "Son seçilen video: $t" else "Son seçilen video: -"
    }

    private fun testYoutube() {
        config.youtubeUrl = etYoutube.text.toString().trim()
        if (config.youtubeUrl.isBlank()) {
            Toast.makeText(this, "Önce bir YouTube videosu seçin veya link girin.",
                Toast.LENGTH_SHORT).show()
            return
        }
        config.musicMode = MusicMode.YOUTUBE
        store.setLastUsed(config)
        val i = Intent(this, FullScreenBannerActivity::class.java)
        i.putExtra(Constants.EXTRA_BANNER_JSON, config.toJson().toString())
        startActivity(i)
    }

    private fun saveAndClose() {
        config.radioUrl = etRadio.text.toString().trim()
        config.youtubeUrl = etYoutube.text.toString().trim()
        store.setLastUsed(config)
        store.save(config)
        Toast.makeText(this, "Müzik/fon ayarı kaydedildi.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
