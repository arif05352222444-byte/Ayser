package com.arif.ledtvbanner.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A recently selected YouTube video (id + best-known title). */
data class RecentYoutubeVideo(val id: String, val title: String)

/**
 * Stores YouTube search history and recently chosen videos using
 * SharedPreferences (JSON). Keeps the last 10 of each. Crash-safe.
 */
class YoutubeStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("led_youtube", Context.MODE_PRIVATE)

    // ---- Recent searches ----

    fun getRecentSearches(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(prefs.getString(KEY_SEARCHES, "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (_: Exception) {}
        return out
    }

    fun addRecentSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val list = getRecentSearches()
        list.remove(q)
        list.add(0, q)
        while (list.size > 10) list.removeAt(list.size - 1)
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString(KEY_SEARCHES, arr.toString()).apply()
    }

    // ---- Recent videos ----

    fun getRecentVideos(): MutableList<RecentYoutubeVideo> {
        val out = mutableListOf<RecentYoutubeVideo>()
        try {
            val arr = JSONArray(prefs.getString(KEY_VIDEOS, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(RecentYoutubeVideo(o.optString("id"), o.optString("title")))
            }
        } catch (_: Exception) {}
        return out
    }

    fun addRecentVideo(id: String, title: String) {
        if (id.isBlank()) return
        val list = getRecentVideos()
        list.removeAll { it.id == id }
        list.add(0, RecentYoutubeVideo(id, if (title.isBlank()) id else title))
        while (list.size > 10) list.removeAt(list.size - 1)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title)) }
        prefs.edit().putString(KEY_VIDEOS, arr.toString()).apply()
    }

    var lastSearchQuery: String
        get() = prefs.getString(KEY_LAST_QUERY, "") ?: ""
        set(v) = prefs.edit().putString(KEY_LAST_QUERY, v).apply()

    companion object {
        private const val KEY_SEARCHES = "recent_searches"
        private const val KEY_VIDEOS = "recent_videos"
        private const val KEY_LAST_QUERY = "last_query"
    }
}
