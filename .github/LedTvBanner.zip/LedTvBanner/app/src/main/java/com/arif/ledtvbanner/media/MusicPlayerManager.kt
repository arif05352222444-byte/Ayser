package com.arif.ledtvbanner.media

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri

/**
 * Plays local MP3 (content/file URI) or an internet radio stream URL using
 * the built-in MediaPlayer. Defensive: any failure calls onError instead of
 * crashing the app.
 */
class MusicPlayerManager(private val context: Context) {

    private var player: MediaPlayer? = null
    var onError: ((String) -> Unit)? = null

    fun playUri(uriString: String, loop: Boolean, volume: Int) {
        release()
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(context, Uri.parse(uriString))
            mp.isLooping = loop
            setVolume(volume, mp)
            mp.setOnErrorListener { _, _, _ ->
                onError?.invoke("Müzik dosyası açılamadı.")
                true
            }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            onError?.invoke("Müzik başlatılamadı: ${e.message}")
        }
    }

    fun playStream(url: String, loop: Boolean, volume: Int) {
        release()
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(url)
            mp.isLooping = loop
            setVolume(volume, mp)
            mp.setOnErrorListener { _, _, _ ->
                onError?.invoke("Radyo bağlantısı açılamadı.")
                true
            }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            onError?.invoke("Radyo başlatılamadı: ${e.message}")
        }
    }

    fun setVolume(volume: Int, mp: MediaPlayer? = player) {
        val v = (volume.coerceIn(0, 100)) / 100f
        try { mp?.setVolume(v, v) } catch (_: Exception) {}
    }

    fun pause() { try { player?.pause() } catch (_: Exception) {} }
    fun resume() { try { player?.start() } catch (_: Exception) {} }

    fun release() {
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) {}
        player = null
    }
}
