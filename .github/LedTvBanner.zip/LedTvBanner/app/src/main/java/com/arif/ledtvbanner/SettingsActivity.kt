package com.arif.ledtvbanner

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.SettingsStore

class SettingsActivity : AppCompatActivity() {

    private lateinit var settings: SettingsStore

    private lateinit var btnAuto: Button
    private lateinit var btnKeepOn: Button
    private lateinit var btnBoot: Button
    private lateinit var seekVolume: SeekBar
    private lateinit var btnDim: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        settings = SettingsStore(this)

        btnAuto = findViewById(R.id.btnAuto)
        btnKeepOn = findViewById(R.id.btnKeepOn)
        btnBoot = findViewById(R.id.btnBoot)
        seekVolume = findViewById(R.id.seekDefVolume)
        btnDim = findViewById(R.id.btnDefDim)

        seekVolume.progress = settings.defaultVolume

        btnAuto.setOnClickListener {
            settings.autoStartLastBanner = !settings.autoStartLastBanner; updateLabels()
        }
        btnKeepOn.setOnClickListener {
            settings.keepScreenOn = !settings.keepScreenOn; updateLabels()
        }
        btnBoot.setOnClickListener {
            settings.startOnBoot = !settings.startOnBoot; updateLabels()
            if (settings.startOnBoot) {
                Toast.makeText(this,
                    "Not: Bazı TV kutuları açılışta otomatik başlatmaya izin vermez.",
                    Toast.LENGTH_LONG).show()
            }
        }
        btnDim.setOnClickListener {
            settings.defaultYoutubeDim = when (settings.defaultYoutubeDim) {
                0 -> 25; 25 -> 50; 50 -> 75; else -> 0
            }
            updateLabels()
        }
        seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                settings.defaultVolume = p
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnReset).setOnClickListener { confirmReset() }

        updateLabels()
        btnAuto.requestFocus()
    }

    private fun updateLabels() {
        btnAuto.text = "Açılışta son banner başlasın:  ${onOff(settings.autoStartLastBanner)}"
        btnKeepOn.text = "Ekran uyumasın:  ${onOff(settings.keepScreenOn)}"
        btnBoot.text = "Cihaz açılınca başlat:  ${onOff(settings.startOnBoot)}"
        btnDim.text = "Varsayılan YouTube karartma:  %${settings.defaultYoutubeDim}"
    }

    private fun onOff(b: Boolean) = if (b) "Açık" else "Kapalı"

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Kayıtları sıfırla")
            .setMessage("Tüm kayıtlı bannerlar silinsin mi?")
            .setPositiveButton("Sıfırla") { _, _ ->
                BannerStore(this).clearAll()
                Toast.makeText(this, "Sıfırlandı.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
