package com.arif.ledtvbanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.util.Constants

/** Shows saved banners as a vertical D-pad list. */
class SavedBannersActivity : AppCompatActivity() {

    private lateinit var store: BannerStore
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saved)
        store = BannerStore(this)
        container = findViewById(R.id.listContainer)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        container.removeAllViews()
        val list = store.getAll()
        if (list.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Henüz kayıtlı banner yok."
            tv.textSize = 22f
            tv.setTextColor(0xFFCCCCCC.toInt())
            tv.setPadding(24, 24, 24, 24)
            container.addView(tv)
            return
        }
        list.forEachIndexed { index, cfg ->
            container.addView(buildRow(index, cfg))
        }
        container.getChildAt(0)?.requestFocus()
    }

    private fun buildRow(index: Int, cfg: BannerConfig): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(20, 16, 20, 16)
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, 14)
        row.layoutParams = lp

        val title = Button(this)
        title.text = "${cfg.name}  —  \"${cfg.text.take(24)}\""
        title.textSize = 20f
        title.background = getDrawable(R.drawable.btn_menu_bg)
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 3f)
        title.layoutParams = tlp
        title.setOnClickListener { startBanner(cfg) }

        val edit = Button(this)
        edit.text = "Düzenle"
        edit.background = getDrawable(R.drawable.btn_menu_bg)
        edit.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        edit.setOnClickListener { editBanner(index, cfg) }

        val del = Button(this)
        del.text = "Sil"
        del.background = getDrawable(R.drawable.btn_menu_bg)
        del.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        del.setOnClickListener { confirmDelete(index, cfg) }

        row.addView(title)
        row.addView(edit)
        row.addView(del)
        return row
    }

    private fun startBanner(cfg: BannerConfig) {
        val i = Intent(this, FullScreenBannerActivity::class.java)
        i.putExtra(Constants.EXTRA_BANNER_JSON, cfg.toJson().toString())
        startActivity(i)
    }

    private fun editBanner(index: Int, cfg: BannerConfig) {
        val i = Intent(this, BannerEditorActivity::class.java)
        i.putExtra(Constants.EXTRA_BANNER_JSON, cfg.toJson().toString())
        i.putExtra(Constants.EXTRA_EDIT_INDEX, index)
        startActivity(i)
    }

    private fun confirmDelete(index: Int, cfg: BannerConfig) {
        AlertDialog.Builder(this)
            .setTitle("Sil")
            .setMessage("\"${cfg.name}\" silinsin mi?")
            .setPositiveButton("Sil") { _, _ ->
                store.deleteAt(index)
                Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }
}
