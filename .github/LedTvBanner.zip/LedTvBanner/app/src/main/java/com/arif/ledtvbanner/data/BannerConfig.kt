package com.arif.ledtvbanner.data

import android.graphics.Color
import org.json.JSONObject

/**
 * All settings for a single LED banner.
 * Everything is stored as simple String enum names so it can be saved
 * to SharedPreferences as JSON without any extra library.
 */
data class BannerConfig(
    var name: String = "Banner",
    var text: String = "HOŞ GELDİNİZ",
    var textColor: TextColor = TextColor.RED,
    var size: TextSize = TextSize.MEDIUM,
    var bold: Boolean = true,
    var speed: ScrollSpeed = ScrollSpeed.NORMAL,
    var direction: ScrollDirection = ScrollDirection.RIGHT_TO_LEFT,
    var ledEffect: LedEffect = LedEffect.DOT,
    var frameEffect: FrameEffect = FrameEffect.COLOR_CHANGING,
    var background: Background = Background.BLACK,

    // Media
    var musicMode: MusicMode = MusicMode.OFF,
    var musicUri: String = "",
    var radioUrl: String = "",
    var youtubeUrl: String = "",
    var youtubeDim: Int = 50,      // 0,25,50,75
    var volume: Int = 80,          // 0..100
    var loop: Boolean = true,
    var selectedVideoTitle: String = ""
) {

    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name)
        put("text", text)
        put("textColor", textColor.name)
        put("size", size.name)
        put("bold", bold)
        put("speed", speed.name)
        put("direction", direction.name)
        put("ledEffect", ledEffect.name)
        put("frameEffect", frameEffect.name)
        put("background", background.name)
        put("musicMode", musicMode.name)
        put("musicUri", musicUri)
        put("radioUrl", radioUrl)
        put("youtubeUrl", youtubeUrl)
        put("youtubeDim", youtubeDim)
        put("volume", volume)
        put("loop", loop)
        put("selectedVideoTitle", selectedVideoTitle)
    }

    fun copyOf(): BannerConfig = fromJson(toJson())

    companion object {
        fun fromJson(o: JSONObject): BannerConfig = BannerConfig(
            name = o.optString("name", "Banner"),
            text = o.optString("text", "HOŞ GELDİNİZ"),
            textColor = enumOr(o.optString("textColor"), TextColor.RED),
            size = enumOr(o.optString("size"), TextSize.LARGE),
            bold = o.optBoolean("bold", true),
            speed = enumOr(o.optString("speed"), ScrollSpeed.NORMAL),
            direction = enumOr(o.optString("direction"), ScrollDirection.RIGHT_TO_LEFT),
            ledEffect = enumOr(o.optString("ledEffect"), LedEffect.NEON_GLOW),
            frameEffect = enumOr(o.optString("frameEffect"), FrameEffect.COLOR_CHANGING),
            background = enumOr(o.optString("background"), Background.BLACK),
            musicMode = enumOr(o.optString("musicMode"), MusicMode.OFF),
            musicUri = o.optString("musicUri", ""),
            radioUrl = o.optString("radioUrl", ""),
            youtubeUrl = o.optString("youtubeUrl", ""),
            youtubeDim = o.optInt("youtubeDim", 50),
            volume = o.optInt("volume", 80),
            loop = o.optBoolean("loop", true),
            selectedVideoTitle = o.optString("selectedVideoTitle", "")
        )

        private inline fun <reified T : Enum<T>> enumOr(value: String?, fallback: T): T {
            if (value.isNullOrEmpty()) return fallback
            return try {
                enumValueOf<T>(value)
            } catch (e: Exception) {
                fallback
            }
        }
    }
}

enum class TextColor(val label: String, val color: Int, val isCycle: Boolean = false) {
    RED("Kırmızı", Color.rgb(255, 40, 40)),
    GREEN("Yeşil", Color.rgb(40, 255, 80)),
    BLUE("Mavi", Color.rgb(60, 120, 255)),
    YELLOW("Sarı", Color.rgb(255, 220, 40)),
    WHITE("Beyaz", Color.rgb(255, 255, 255)),
    PURPLE("Mor", Color.rgb(190, 80, 255)),
    ORANGE("Turuncu", Color.rgb(255, 140, 20)),
    RGB_CYCLE("RGB / Renk Döngüsü", Color.rgb(255, 40, 40), isCycle = true)
}

enum class TextSize(val label: String, val ledRows: Int, val bandFraction: Float) {
    SMALL("Küçük", 13, 0.24f),
    MEDIUM("Orta", 15, 0.34f),
    LARGE("Büyük", 17, 0.44f),
    HUGE("Dev", 19, 0.56f)
}

enum class ScrollSpeed(val label: String, val pixelsPerSecond: Float) {
    VERY_SLOW("Çok yavaş", 160f),
    SLOW("Yavaş", 300f),
    NORMAL("Normal", 480f),
    FAST("Hızlı", 720f),
    VERY_FAST("Çok hızlı", 1050f)
}

enum class ScrollDirection(val label: String) {
    RIGHT_TO_LEFT("Sağdan sola"),
    LEFT_TO_RIGHT("Soldan sağa"),
    TOP_TO_BOTTOM("Yukarıdan aşağı"),
    BOTTOM_TO_TOP("Aşağıdan yukarı"),
    BLINK_STATIC("Sabit yanıp sönen")
}

enum class LedEffect(val label: String) {
    DOT("Noktalı LED"),
    NEON_GLOW("Neon parlama"),
    BLUR_GLOW("Hafif glow"),
    BLINK("Yanıp sönme"),
    COLOR_CYCLE("Renk değişimi"),
    PLAIN("Sade")
}

enum class FrameEffect(val label: String) {
    OFF("Kapalı"),
    SOLID("Sabit renkli çerçeve"),
    COLOR_CHANGING("Renk değiştiren çerçeve"),
    RUNNING_DOTS("Kayan nokta çerçeve"),
    BLINKING("Yanıp sönen çerçeve")
}

enum class Background(val label: String) {
    BLACK("Siyah"),
    DARK_GRAY("Koyu gri"),
    LED_GRID("LED panel ızgara"),
    REFLECTIVE("Hafif yansımalı panel"),
    YOUTUBE_DIM("YouTube fon (karartma)")
}

enum class MusicMode(val label: String) {
    OFF("Kapalı"),
    LOCAL_MP3("Cihazdan / USB MP3"),
    RADIO("İnternet radyo"),
    YOUTUBE("YouTube fon")
}
